export interface FieldConfig {
    name: string;
    label: string;
    required: boolean;
}
export interface ProfilesConfig {
    avatarMode: 'identicon' | 'avatar-required' | 'avatar-optional';
    additionalFields: FieldConfig[];
    minNicknameLength: number;
}
export declare const defaultConfig: ProfilesConfig;
