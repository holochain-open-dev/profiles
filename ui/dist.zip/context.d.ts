import { ProfilesStore } from "./profiles-store";
export declare const profilesStoreContext: {
    __context__: ProfilesStore;
};
