import { EntryRecord, ZomeClient, } from "@holochain-open-dev/utils";
export class ProfilesClient extends ZomeClient {
    constructor(client, roleName, zomeName = "profiles") {
        super(client, roleName, zomeName);
        this.client = client;
        this.roleName = roleName;
        this.zomeName = zomeName;
    }
    /**
     * Get the profile for the given agent, if they have created it
     *
     * @param agentPubKey the agent to get the profile for
     * @returns the profile of the agent, if they have created one
     */
    async getAgentProfile(agentPubKey) {
        const record = await this.callZome("get_agent_profile", agentPubKey);
        return record ? new EntryRecord(record) : undefined;
    }
    /**
     * Search profiles that start with nicknameFilter
     *
     * @param nicknameFilter must be of at least 3 characters
     * @returns the agents with the nickname starting with nicknameFilter
     */
    async searchAgents(nicknameFilter) {
        return this.callZome("search_agents", nicknameFilter);
    }
    /**
     * Get all the agents in the DHT that have created a profile
     *
     * @returns the agent public keys of all agents that have created a profile
     */
    async getAgentsWithProfile() {
        return this.callZome("get_agents_with_profile", null);
    }
    /**
     * Create my profile
     *
     * @param profile the profile to create
     */
    async createProfile(profile) {
        const record = await this.callZome("create_profile", profile);
        return new EntryRecord(record);
    }
    /**
     * Update my profile
     *
     * @param profile the profile to create
     */
    async updateProfile(profile) {
        const record = await this.callZome("update_profile", profile);
        return new EntryRecord(record);
    }
}
//# sourceMappingURL=profiles-client.js.map