import { HoloHash } from "@holochain/client";
export declare function uniquify<H extends HoloHash>(array: Array<H>): Array<H>;
