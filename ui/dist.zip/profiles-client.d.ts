import { EntryRecord, ZomeClient } from "@holochain-open-dev/utils";
import { AgentPubKey, AppAgentClient, RoleName } from "@holochain/client";
import { Profile, ProfilesSignal } from "./types";
export declare class ProfilesClient extends ZomeClient<ProfilesSignal> {
    client: AppAgentClient;
    roleName: RoleName;
    zomeName: string;
    constructor(client: AppAgentClient, roleName: RoleName, zomeName?: string);
    /**
     * Get the profile for the given agent, if they have created it
     *
     * @param agentPubKey the agent to get the profile for
     * @returns the profile of the agent, if they have created one
     */
    getAgentProfile(agentPubKey: AgentPubKey): Promise<EntryRecord<Profile> | undefined>;
    /**
     * Search profiles that start with nicknameFilter
     *
     * @param nicknameFilter must be of at least 3 characters
     * @returns the agents with the nickname starting with nicknameFilter
     */
    searchAgents(nicknameFilter: string): Promise<AgentPubKey[]>;
    /**
     * Get all the agents in the DHT that have created a profile
     *
     * @returns the agent public keys of all agents that have created a profile
     */
    getAgentsWithProfile(): Promise<AgentPubKey[]>;
    /**
     * Create my profile
     *
     * @param profile the profile to create
     */
    createProfile(profile: Profile): Promise<EntryRecord<Profile>>;
    /**
     * Update my profile
     *
     * @param profile the profile to create
     */
    updateProfile(profile: Profile): Promise<EntryRecord<Profile>>;
}
