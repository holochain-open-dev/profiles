import { AgentPubKeyMap, ZomeMock } from "@holochain-open-dev/utils";
import { AgentPubKey, AppAgentClient, Record } from "@holochain/client";
import { ProfilesClient } from "./profiles-client";
import { Profile } from "./types";
export declare function demoProfiles(): Promise<AgentPubKeyMap<Record>>;
export declare class ProfilesZomeMock extends ZomeMock implements AppAgentClient {
    agentsProfiles: AgentPubKeyMap<Record>;
    constructor(agentsProfiles: AgentPubKeyMap<Record>, myPubKey?: AgentPubKey);
    create_profile(profile: Profile): Promise<Record>;
    update_profile(profile: Profile): Promise<Record>;
    search_agents(nickname_filter: string): Uint8Array[];
    get_agent_profile(agent_address: AgentPubKey): Record;
    get_agents_with_profile(): Uint8Array[];
}
export declare function sampleProfile(client: ProfilesClient, partialProfile?: Partial<Profile>): Promise<Profile>;
