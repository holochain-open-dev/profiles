import { LitElement } from "lit";
import { AgentPubKey } from "@holochain/client";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@holochain-open-dev/elements/dist/elements/holo-identicon.js";
import "@shoelace-style/shoelace/dist/components/avatar/avatar.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "@shoelace-style/shoelace/dist/components/tooltip/tooltip.js";
import { ProfilesStore } from "../profiles-store.js";
import { Profile } from "../types.js";
import { EntryRecord } from "@holochain-open-dev/utils";
export declare class AgentAvatar extends LitElement {
    /** Public properties */
    /**
     * REQUIRED. The public key identifying the agent whose profile is going to be shown.
     */
    agentPubKey: AgentPubKey;
    /**
     * Size of the avatar image in pixels.
     */
    size: number;
    /**
     * Disables showing the tooltip for the public key
     */
    disableTooltip: boolean;
    /**
     * Disable copying of the public key on click
     */
    disableCopy: boolean;
    /** Dependencies */
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /**
     * @internal
     */
    private _agentProfile;
    renderIdenticon(): import("lit-html").TemplateResult<1>;
    /**
     * @internal
     */
    timeout: any;
    renderProfile(profile: EntryRecord<Profile> | undefined): import("lit-html").TemplateResult<1>;
    render(): import("lit-html").TemplateResult<1>;
    static styles: (import("lit").CSSResult | import("lit").CSSResult[])[];
}
