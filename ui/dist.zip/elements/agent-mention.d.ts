import { LitElement } from "lit";
import { AgentPubKey } from "@holochain/client";
import { EntryRecord } from "@holochain-open-dev/utils";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@holochain-open-dev/elements/dist/elements/holo-identicon.js";
import "@shoelace-style/shoelace/dist/components/avatar/avatar.js";
import "@shoelace-style/shoelace/dist/components/tag/tag.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "@shoelace-style/shoelace/dist/components/tooltip/tooltip.js";
import { ProfilesStore } from "../profiles-store.js";
import { Profile } from "../types.js";
export declare class AgentMention extends LitElement {
    /** Public properties */
    /**
     * REQUIRED. The public key identifying the agent whose profile is going to be shown.
     */
    agentPubKey: AgentPubKey;
    /**
     * Size of the avatar image in pixels.
     */
    size: number;
    /** Dependencies */
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /**
     * @internal
     */
    private _agentProfile;
    renderAvatar(profile: EntryRecord<Profile> | undefined): import("lit-html").TemplateResult<1>;
    renderProfile(profile: EntryRecord<Profile> | undefined): import("lit-html").TemplateResult<1>;
    renderContent(): import("lit-html").TemplateResult<1>;
    render(): import("lit-html").TemplateResult<1>;
    static styles: (import("lit").CSSResult | import("lit").CSSResult[])[];
}
