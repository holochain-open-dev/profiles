export declare function resizeAndExport(img: HTMLImageElement): string;
