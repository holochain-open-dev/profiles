import { __decorate } from "tslib";
import { hashProperty, sharedStyles } from "@holochain-open-dev/elements";
import { StoreSubscriber } from "@holochain-open-dev/stores";
import { consume } from "@lit/context";
import { LitElement, html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { localized, msg } from "@lit/localize";
import "./agent-avatar.js";
import "./profile-list-item-skeleton.js";
import { profilesStoreContext } from "../context.js";
/**
 * @element profile-list-item
 */
let ProfileListItem = class ProfileListItem extends LitElement {
    constructor() {
        super(...arguments);
        /**
         * @internal
         */
        this._profile = new StoreSubscriber(this, () => this.store.profiles.get(this.agentPubKey), () => [this.store, this.agentPubKey]);
    }
    render() {
        var _a;
        switch (this._profile.value.status) {
            case "pending":
                return html `<profile-list-item-skeleton></profile-list-item-skeleton>`;
            case "complete":
                return html `
          <div class="row" style="align-items: center; gap: 8px">
            <agent-avatar .agentPubKey=${this.agentPubKey}></agent-avatar>
            <span>${(_a = this._profile.value.value) === null || _a === void 0 ? void 0 : _a.entry.nickname}</span>
          </div>
        `;
            case "error":
                return html `<display-error
          tooltip
          .headline=${msg("Error fetching the profile")}
          .error=${this._profile.value.error}
        ></display-error>`;
        }
    }
};
ProfileListItem.styles = [sharedStyles];
__decorate([
    property(hashProperty("agent-pub-key"))
], ProfileListItem.prototype, "agentPubKey", void 0);
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], ProfileListItem.prototype, "store", void 0);
ProfileListItem = __decorate([
    localized(),
    customElement("profile-list-item")
], ProfileListItem);
export { ProfileListItem };
//# sourceMappingURL=profile-list-item.js.map