import { __decorate } from "tslib";
import { css, html, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
import { consume } from "@lit/context";
import { sharedStyles } from "@holochain-open-dev/elements";
import { StoreSubscriber } from "@holochain-open-dev/stores";
import { localized, msg } from "@lit/localize";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "./agent-avatar.js";
import "./profile-list-item-skeleton.js";
import { profilesStoreContext } from "../context";
/**
 * @element list-profiles
 * @fires agent-selected - Fired when the user selects an agent from the list. Detail will have this shape: { agentPubKey: <AGENT_PUB_KEY as Uint8Array> }
 */
let ListProfiles = class ListProfiles extends LitElement {
    constructor() {
        super(...arguments);
        /** Private properties */
        /**
         * @internal
         */
        this._allProfiles = new StoreSubscriber(this, () => this.store.allProfiles, () => [this.store]);
    }
    initials(nickname) {
        return nickname
            .split(" ")
            .map((name) => name[0])
            .join("");
    }
    fireAgentSelected(agentPubKey) {
        if (agentPubKey) {
            this.dispatchEvent(new CustomEvent("agent-selected", {
                bubbles: true,
                composed: true,
                detail: {
                    agentPubKey,
                },
            }));
        }
    }
    renderList(profiles) {
        if (profiles.size === 0)
            return html `<span>${msg("There are no created profiles yet")} ></span>`;
        return html `
      <div style="min-width: 80px; flex: 1;" }>
        ${Array.from(profiles.entries()).map(([agent_pub_key, profile]) => html `
            <div class="row" style="align-items: center; margin-bottom: 16px;">
              <agent-avatar
                style="margin-right: 8px;"
                .agentPubKey=${agent_pub_key}
                @click=${() => this.fireAgentSelected(agent_pub_key)}
              >
              </agent-avatar
              ><span> ${profile.entry.nickname}</span>
            </div>
          `)}
      </div>
    `;
    }
    render() {
        switch (this._allProfiles.value.status) {
            case "pending":
                return html `<div class="column center-content">
          <profile-list-item-skeleton> </profile-list-item-skeleton>
          <profile-list-item-skeleton> </profile-list-item-skeleton>
          <profile-list-item-skeleton> </profile-list-item-skeleton>
        </div>`;
            case "error":
                return html `<display-error
          .headline=${msg("Error fetching the profiles for all agents")}
          .error=${this._allProfiles.value.error}
        ></display-error>`;
            case "complete":
                return this.renderList(this._allProfiles.value.value);
        }
    }
};
ListProfiles.styles = [
    sharedStyles,
    css `
      :host {
        display: flex;
      }
    `,
];
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], ListProfiles.prototype, "store", void 0);
ListProfiles = __decorate([
    localized(),
    customElement("list-profiles")
], ListProfiles);
export { ListProfiles };
//# sourceMappingURL=list-profiles.js.map