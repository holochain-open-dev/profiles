import { __decorate } from "tslib";
import { css, html, LitElement } from "lit";
import { provide } from "@lit/context";
import { property, customElement } from "lit/decorators.js";
import { profilesStoreContext } from "../context.js";
let ProfilesContext = class ProfilesContext extends LitElement {
    render() {
        return html `<slot></slot>`;
    }
};
ProfilesContext.styles = css `
    :host {
      display: contents;
    }
  `;
__decorate([
    provide({ context: profilesStoreContext }),
    property({ type: Object })
], ProfilesContext.prototype, "store", void 0);
ProfilesContext = __decorate([
    customElement("profiles-context")
], ProfilesContext);
export { ProfilesContext };
//# sourceMappingURL=profiles-context.js.map