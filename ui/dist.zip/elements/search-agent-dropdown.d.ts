import { LitElement } from "lit";
import { AgentPubKey } from "@holochain/client";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "@shoelace-style/shoelace/dist/components/menu/menu.js";
import "@shoelace-style/shoelace/dist/components/menu-item/menu-item.js";
import "@shoelace-style/shoelace/dist/components/dropdown/dropdown.js";
import "@shoelace-style/shoelace/dist/components/input/input.js";
import SlDropdown from "@shoelace-style/shoelace/dist/components/dropdown/dropdown.js";
import "./agent-avatar.js";
import "./profile-list-item-skeleton.js";
import { ProfilesStore } from "../profiles-store.js";
/**
 * @element search-agent-dropdown
 * @fires agent-selected - Fired when the user selects some agent. Detail will have this shape: { agentPubKey: HoloHash }
 */
export declare class SearchAgentDropdown extends LitElement {
    /** Public attributes */
    searchFilter: string | undefined;
    open: boolean | undefined;
    /**
     * Whether to include my own agent as a possible agent to select.
     * @attr include-myself
     */
    includeMyself: boolean;
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /**
     * @internal
     */
    private _searchProfiles;
    /**
     * @internal
     */
    dropdown: SlDropdown;
    onUsernameSelected(agentPubKey: AgentPubKey): Promise<void>;
    renderAgentList(): import("lit-html").TemplateResult<1> | import("lit-html").TemplateResult<1>[];
    render(): import("lit-html").TemplateResult<1>;
    static get styles(): (import("lit").CSSResult | import("lit").CSSResult[])[];
}
