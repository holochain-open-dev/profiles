import { LitElement } from "lit";
import "@shoelace-style/shoelace/dist/components/icon-button/icon-button.js";
import { ProfilesStore } from "../profiles-store.js";
import "./update-profile.js";
import "./profile-detail.js";
/**
 * @element my-profile
 */
export declare class MyProfile extends LitElement {
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /** Private properties */
    /**
     * @internal
     */
    private _editing;
    render(): import("lit-html").TemplateResult<1>;
    static styles: import("lit").CSSResult[][];
}
