import { SlTextareaProsemirror } from "@holochain-open-dev/elements/dist/elements/sl-textarea-prosemirror.js";
import { DnaHash } from "@holochain/client";
import { Schema, NodeSpec } from "prosemirror-model";
import { Plugin, PluginKey } from "prosemirror-state";
import { ProfilesStore } from "../profiles-store.js";
import "./search-agent-dropdown.js";
import "./agent-mention.js";
import { SearchAgentDropdown } from "./search-agent-dropdown.js";
export declare const agentMentionSpec: NodeSpec;
export type SearchAgentPluginState = {
    dropdownEl: SearchAgentDropdown;
    mentionCharIndex: number;
    lastCharIndex: number;
} | "hidden";
export declare const pluginKey: PluginKey<any>;
export declare const searchAgentPlugin: Plugin<SearchAgentPluginState>;
export declare class TextareaWithMentions extends SlTextareaProsemirror {
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    dnaHash: DnaHash;
    firstUpdated(): Promise<void>;
    helpText: string;
    get value(): string;
    set value(v: string);
    editorStateConfig(): {
        schema: Schema<"agentMention" | "doc" | "paragraph" | "text", any>;
        plugins: (Plugin<SearchAgentPluginState> | Plugin<any>)[];
    };
}
