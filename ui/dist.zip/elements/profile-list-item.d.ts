import { AgentPubKey } from "@holochain/client";
import { LitElement } from "lit";
import "./agent-avatar.js";
import "./profile-list-item-skeleton.js";
import { ProfilesStore } from "../profiles-store.js";
/**
 * @element profile-list-item
 */
export declare class ProfileListItem extends LitElement {
    /**
     * REQUIRED: the public key of the agent to render the profile for
     */
    agentPubKey: AgentPubKey;
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /**
     * @internal
     */
    private _profile;
    render(): import("lit-html").TemplateResult<1>;
    static styles: import("lit").CSSResult[][];
}
