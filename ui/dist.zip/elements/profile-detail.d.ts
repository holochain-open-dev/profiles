import { AgentPubKey } from "@holochain/client";
import { LitElement } from "lit";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "./agent-avatar.js";
import { ProfilesStore } from "../profiles-store.js";
import { Profile } from "../types.js";
import { EntryRecord } from "@holochain-open-dev/utils";
/**
 * @element profile-detail
 */
export declare class ProfileDetail extends LitElement {
    /** Public properties */
    /**
     * REQUIRED. Public key identifying the agent for which the profile should be shown
     */
    agentPubKey: AgentPubKey;
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /** Private properties */
    /**
     * @internal
     */
    private _agentProfile;
    getAdditionalFields(profile: Profile): Record<string, string>;
    renderAdditionalField(fieldId: string, fieldValue: string): import("lit-html").TemplateResult<1>;
    renderProfile(profile: EntryRecord<Profile> | undefined): import("lit-html").TemplateResult<1>;
    render(): import("lit-html").TemplateResult<1>;
    static styles: import("lit").CSSResult[][];
}
