import { __decorate } from "tslib";
import { consume } from "@lit/context";
import { hashProperty, sharedStyles } from "@holochain-open-dev/elements";
import { css, html, LitElement } from "lit";
import { property, customElement } from "lit/decorators.js";
import { styleMap } from "lit-html/directives/style-map.js";
import { localized, msg } from "@lit/localize";
import { StoreSubscriber } from "@holochain-open-dev/stores";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@holochain-open-dev/elements/dist/elements/holo-identicon.js";
import "@shoelace-style/shoelace/dist/components/avatar/avatar.js";
import "@shoelace-style/shoelace/dist/components/tag/tag.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "@shoelace-style/shoelace/dist/components/tooltip/tooltip.js";
import { profilesStoreContext } from "../context.js";
let AgentMention = class AgentMention extends LitElement {
    constructor() {
        /** Public properties */
        super(...arguments);
        /**
         * Size of the avatar image in pixels.
         */
        this.size = 24;
        /**
         * @internal
         */
        this._agentProfile = new StoreSubscriber(this, () => this.store.profiles.get(this.agentPubKey), () => [this.agentPubKey, this.store]);
    }
    renderAvatar(profile) {
        if (!profile || !profile.entry.fields.avatar) {
            return html ` <div
        style=${styleMap({
                position: "relative",
                height: `${this.size}px`,
                width: `${this.size}px`,
            })}
      >
        <holo-identicon
          .disableCopy=${true}
          .disableTooltip=${true}
          .hash=${this.agentPubKey}
          .size=${this.size}
        >
        </holo-identicon>
      </div>`;
        }
        return html `
      <sl-avatar
        .image=${profile.entry.fields.avatar}
        style="--size: ${this.size}px;"
      >
      </sl-avatar>
    `;
    }
    renderProfile(profile) {
        return html `
      <div class="row">
        ${this.renderAvatar(profile)}
        <span style="margin-left: 8px">${profile === null || profile === void 0 ? void 0 : profile.entry.nickname}</span>
      </div>
    `;
    }
    renderContent() {
        switch (this._agentProfile.value.status) {
            case "pending":
                return html `<sl-skeleton effect="pulse"></sl-skeleton>`;
            case "complete":
                return this.renderProfile(this._agentProfile.value.value);
            case "error":
                return html `
          <display-error
            tooltip
            .headline=${msg("Error fetching the agent's avatar")}
            .error=${this._agentProfile.value.error}
          ></display-error>
        `;
        }
    }
    render() {
        return html `
      <sl-tag pill style="display: inline-flex">${this.renderContent()}</sl-tag>
    `;
    }
};
AgentMention.styles = [
    sharedStyles,
    css `
      :host {
        display: inline-flex;
      }
    `,
];
__decorate([
    property(hashProperty("agent-pub-key"))
], AgentMention.prototype, "agentPubKey", void 0);
__decorate([
    property({ type: Number })
], AgentMention.prototype, "size", void 0);
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], AgentMention.prototype, "store", void 0);
AgentMention = __decorate([
    localized(),
    customElement("agent-mention")
], AgentMention);
export { AgentMention };
//# sourceMappingURL=agent-mention.js.map