import { __decorate } from "tslib";
import { consume } from "@lit/context";
import { hashProperty, sharedStyles, } from "@holochain-open-dev/elements";
import { css, html, LitElement } from "lit";
import { property, customElement } from "lit/decorators.js";
import { styleMap } from "lit-html/directives/style-map.js";
import { localized, msg } from "@lit/localize";
import { StoreSubscriber } from "@holochain-open-dev/stores";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@holochain-open-dev/elements/dist/elements/holo-identicon.js";
import "@shoelace-style/shoelace/dist/components/avatar/avatar.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "@shoelace-style/shoelace/dist/components/tooltip/tooltip.js";
import { profilesStoreContext } from "../context.js";
let AgentAvatar = class AgentAvatar extends LitElement {
    constructor() {
        /** Public properties */
        super(...arguments);
        /**
         * Size of the avatar image in pixels.
         */
        this.size = 32;
        /**
         * Disables showing the tooltip for the public key
         */
        this.disableTooltip = false;
        /**
         * Disable copying of the public key on click
         */
        this.disableCopy = false;
        /**
         * @internal
         */
        this._agentProfile = new StoreSubscriber(this, () => this.store.profiles.get(this.agentPubKey), () => [this.agentPubKey, this.store]);
    }
    renderIdenticon() {
        return html ` <div
      style=${styleMap({
            position: "relative",
            height: `${this.size}px`,
            width: `${this.size}px`,
        })}
    >
      <holo-identicon
        .disableCopy=${this.disableCopy}
        .disableTooltip=${this.disableTooltip}
        .hash=${this.agentPubKey}
        .size=${this.size}
      >
      </holo-identicon>
      <div class="badge"><slot name="badge"></slot></div>
    </div>`;
    }
    renderProfile(profile) {
        if (!profile || !profile.entry.fields.avatar)
            return this.renderIdenticon();
        const contents = html `
      <div
        style=${styleMap({
            cursor: this.disableCopy ? "" : "pointer",
            position: "relative",
            height: `${this.size}px`,
            width: `${this.size}px`,
        })}
      >
        <sl-avatar
          .image=${profile.entry.fields.avatar}
          style="--size: ${this.size}px;"
          @click=${() => this.dispatchEvent(new CustomEvent("profile-clicked", {
            composed: true,
            bubbles: true,
            detail: {
                agentPubKey: this.agentPubKey,
            },
        }))}
        >
        </sl-avatar>
        <div class="badge"><slot name="badge"></slot></div>
      </div>
    `;
        return html `
      <sl-tooltip
        id="tooltip"
        placement="top"
        .trigger=${this.disableTooltip ? "manual" : "hover focus"}
        hoist
        .content=${profile.entry.nickname}
      >
        ${contents}
      </sl-tooltip>
    `;
    }
    render() {
        if (this.store.config.avatarMode === "identicon")
            return this.renderIdenticon();
        switch (this._agentProfile.value.status) {
            case "pending":
                return html `<sl-skeleton
          effect="pulse"
          style="height: ${this.size}px; width: ${this.size}px"
        ></sl-skeleton>`;
            case "complete":
                return this.renderProfile(this._agentProfile.value.value);
            case "error":
                return html `
          <display-error
            tooltip
            .headline=${msg("Error fetching the agent's avatar")}
            .error=${this._agentProfile.value.error}
          ></display-error>
        `;
        }
    }
};
AgentAvatar.styles = [
    sharedStyles,
    css `
      .badge {
        position: absolute;
        right: 0;
        bottom: 0;
      }
    `,
];
__decorate([
    property(hashProperty("agent-pub-key"))
], AgentAvatar.prototype, "agentPubKey", void 0);
__decorate([
    property({ type: Number })
], AgentAvatar.prototype, "size", void 0);
__decorate([
    property({ type: Boolean, attribute: "disable-tooltip" })
], AgentAvatar.prototype, "disableTooltip", void 0);
__decorate([
    property({ type: Boolean, attribute: "disable-copy" })
], AgentAvatar.prototype, "disableCopy", void 0);
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], AgentAvatar.prototype, "store", void 0);
AgentAvatar = __decorate([
    localized(),
    customElement("agent-avatar")
], AgentAvatar);
export { AgentAvatar };
//# sourceMappingURL=agent-avatar.js.map