import { __decorate } from "tslib";
import { LitElement, html } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import "@shoelace-style/shoelace/dist/components/icon-button/icon-button.js";
import { FormFieldController, hashProperty, sharedStyles, wrapPathInSvg, } from "@holochain-open-dev/elements";
import { localized, msg } from "@lit/localize";
import { mdiDelete } from "@mdi/js";
import "./profile-list-item.js";
import "./search-agent.js";
/**
 * @element search-agents
 */
let SearchAgents = class SearchAgents extends LitElement {
    constructor() {
        /** Form field properties */
        super(...arguments);
        /**
         * The default value of the field if this element is used inside a form
         */
        this.defaultValue = [];
        /**
         * Whether this field is required if this element is used inside a form
         */
        this.required = false;
        /**
         * Whether this field is disabled if this element is used inside a form
         */
        this.disabled = false;
        /**
         * Placeholder to show when the list is empty.
         * @attr empty-list-placeholder
         */
        this.emptyListPlaceholder = msg("No agents selected yet.");
        /**
         * Whether to include my own agent as a possible agent to select.
         * @attr include-myself
         */
        this.includeMyself = false;
        /**
         * @internal
         */
        this._controller = new FormFieldController(this);
        /**
         * @internal
         */
        this.value = [];
    }
    reportValidity() {
        return true;
    }
    async reset() {
        this.value = this.defaultValue;
    }
    render() {
        return html `
      <div class="column" style="gap: 16px">
        <search-agent
          .fieldLabel=${this.fieldLabel}
          clear-on-select
          @agent-selected=${(e) => {
            this.value = [...this.value, e.detail.agentPubKey];
        }}
          .includeMyself=${this.includeMyself}
        ></search-agent>
        ${this.value.length === 0
            ? html `<span class="placeholder">${this.emptyListPlaceholder}</span>`
            : this.value.map((agent, i) => html `<div class="row">
                  <profile-list-item
                    style="flex: 1"
                    .agentPubKey=${agent}
                  ></profile-list-item
                  ><sl-icon-button
                    .src=${wrapPathInSvg(mdiDelete)}
                    @click=${() => {
                this.value = this.value.filter((v, i2) => i2 !== i);
            }}
                  ></sl-icon-button>
                </div>`)}
      </div>
    `;
    }
};
SearchAgents.styles = [sharedStyles];
__decorate([
    property()
], SearchAgents.prototype, "name", void 0);
__decorate([
    property(hashProperty("default-value"))
], SearchAgents.prototype, "defaultValue", void 0);
__decorate([
    property()
], SearchAgents.prototype, "required", void 0);
__decorate([
    property()
], SearchAgents.prototype, "disabled", void 0);
__decorate([
    property({ type: String, attribute: "field-label" })
], SearchAgents.prototype, "fieldLabel", void 0);
__decorate([
    property({ type: String, attribute: "empty-list-placeholder" })
], SearchAgents.prototype, "emptyListPlaceholder", void 0);
__decorate([
    property({ type: Boolean, attribute: "include-myself" })
], SearchAgents.prototype, "includeMyself", void 0);
__decorate([
    state()
], SearchAgents.prototype, "value", void 0);
SearchAgents = __decorate([
    localized(),
    customElement("search-agents")
], SearchAgents);
export { SearchAgents };
//# sourceMappingURL=search-agents.js.map