import { __decorate } from "tslib";
import { css, html, LitElement } from "lit";
import { property, customElement } from "lit/decorators.js";
import { localized, msg } from "@lit/localize";
import { consume } from "@lit/context";
import { subscribe } from "@holochain-open-dev/stores";
import { renderAsyncStatus, sharedStyles } from "@holochain-open-dev/elements";
import "@shoelace-style/shoelace/dist/components/spinner/spinner.js";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "./create-profile.js";
import { profilesStoreContext } from "../context.js";
/**
 * @element profile-prompt
 * @slot hero - Will be displayed above the create-profile form when the user is prompted with it
 */
let ProfilePrompt = class ProfilePrompt extends LitElement {
    /** Private properties */
    renderPrompt(myProfile) {
        if (myProfile)
            return html `<slot></slot>`;
        return html `
      <div
        class="column"
        style="align-items: center; justify-content: center; flex: 1; padding-bottom: 10px;"
      >
        <div class="column" style="align-items: center;">
          <slot name="hero"></slot>
          <create-profile></create-profile>
        </div>
      </div>
    `;
    }
    render() {
        return html `${subscribe(this.store.myProfile, renderAsyncStatus({
            complete: (p) => this.renderPrompt(p),
            pending: () => html `<div
          style="display: flex; flex-direction: column; align-items: center; justify-content: center; flex: 1;"
        >
          <sl-spinner style="font-size: 2rem;"></sl-spinner>
        </div>`,
            error: (e) => html `<display-error
            .error=${e}
            .headline=${msg("Error fetching your profile")}
          ></display-error>`,
        }))}`;
    }
    static get styles() {
        return [
            sharedStyles,
            css `
        :host {
          display: flex;
          flex: 1;
        }
      `,
        ];
    }
};
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], ProfilePrompt.prototype, "store", void 0);
ProfilePrompt = __decorate([
    localized(),
    customElement("profile-prompt")
], ProfilePrompt);
export { ProfilePrompt };
//# sourceMappingURL=profile-prompt.js.map