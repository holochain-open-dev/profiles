import { LitElement } from "lit";
import "@shoelace-style/shoelace/dist/components/icon-button/icon-button.js";
import { FormField, FormFieldController } from "@holochain-open-dev/elements";
import { AgentPubKey } from "@holochain/client";
import "./profile-list-item.js";
import "./search-agent.js";
/**
 * @element search-agents
 */
export declare class SearchAgents extends LitElement implements FormField {
    /** Form field properties */
    /**
     * The name of the field if this element is used inside a form
     * Required only if the element is used inside a form
     */
    name: string;
    /**
     * The default value of the field if this element is used inside a form
     */
    defaultValue: Array<AgentPubKey>;
    /**
     * Whether this field is required if this element is used inside a form
     */
    required: boolean;
    /**
     * Whether this field is disabled if this element is used inside a form
     */
    disabled: boolean;
    /**
     * Label for the agent searching field.
     * @attr field-label
     */
    fieldLabel: string;
    /**
     * Placeholder to show when the list is empty.
     * @attr empty-list-placeholder
     */
    emptyListPlaceholder: string;
    /**
     * Whether to include my own agent as a possible agent to select.
     * @attr include-myself
     */
    includeMyself: boolean;
    /**
     * @internal
     */
    _controller: FormFieldController;
    reportValidity(): boolean;
    reset(): Promise<void>;
    /**
     * @internal
     */
    value: AgentPubKey[];
    render(): import("lit-html").TemplateResult<1>;
    static styles: import("lit").CSSResult[][];
}
