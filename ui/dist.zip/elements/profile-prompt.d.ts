import { LitElement } from "lit";
import { EntryRecord } from "@holochain-open-dev/utils";
import "@shoelace-style/shoelace/dist/components/spinner/spinner.js";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "./create-profile.js";
import { ProfilesStore } from "../profiles-store.js";
import { Profile } from "../types.js";
/**
 * @element profile-prompt
 * @slot hero - Will be displayed above the create-profile form when the user is prompted with it
 */
export declare class ProfilePrompt extends LitElement {
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /** Private properties */
    renderPrompt(myProfile: EntryRecord<Profile> | undefined): import("lit-html").TemplateResult<1>;
    render(): import("lit-html").TemplateResult<1>;
    static get styles(): (import("lit").CSSResult | import("lit").CSSResult[])[];
}
