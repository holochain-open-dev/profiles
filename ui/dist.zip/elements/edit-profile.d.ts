import { LitElement } from "lit";
import { EntryRecord } from "@holochain-open-dev/utils";
import "@shoelace-style/shoelace/dist/components/avatar/avatar.js";
import "@shoelace-style/shoelace/dist/components/button/button.js";
import "@shoelace-style/shoelace/dist/components/input/input.js";
import "@shoelace-style/shoelace/dist/components/icon/icon.js";
import "@holochain-open-dev/elements/dist/elements/select-avatar.js";
import { ProfilesStore } from "../profiles-store.js";
import { Profile } from "../types.js";
import { FieldConfig } from "../config.js";
/**
 * @element edit-profile
 * @fires save-profile - Fired when the save profile button is clicked
 */
export declare class EditProfile extends LitElement {
    /**
     * The profile to be edited.
     */
    profile: EntryRecord<Profile> | undefined;
    /**
     * Label for the save profile button.
     */
    saveProfileLabel: string | undefined;
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    allowCancel: boolean;
    /** Private properties */
    avatarMode(): boolean;
    fireSaveProfile(fields: Record<string, string>): void;
    fireCancel(): void;
    renderField(fieldConfig: FieldConfig): import("lit-html").TemplateResult<1>;
    render(): import("lit-html").TemplateResult<1>;
    static styles: import("lit").CSSResult[][];
}
