import { __decorate } from "tslib";
import { consume } from "@lit/context";
import { html, LitElement } from "lit";
import { property, state, customElement } from "lit/decorators.js";
import { sharedStyles, wrapPathInSvg } from "@holochain-open-dev/elements";
import { mdiPencil } from "@mdi/js";
import "@shoelace-style/shoelace/dist/components/icon-button/icon-button.js";
import { profilesStoreContext } from "../context.js";
import "./update-profile.js";
import "./profile-detail.js";
/**
 * @element my-profile
 */
let MyProfile = class MyProfile extends LitElement {
    constructor() {
        super(...arguments);
        /** Private properties */
        /**
         * @internal
         */
        this._editing = false;
    }
    render() {
        if (this._editing)
            return html `<update-profile
        @profile-updated=${() => (this._editing = false)}
        @cancel-edit-profile=${() => (this._editing = false)}
      ></update-profile>`;
        return html `
      <profile-detail .agentPubKey=${this.store.client.client.myPubKey}>
        <sl-icon-button
          src="${wrapPathInSvg(mdiPencil)}"
          slot="action"
          @click=${() => (this._editing = true)}
        ></sl-icon-button>
      </profile-detail>
    `;
    }
};
MyProfile.styles = [sharedStyles];
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], MyProfile.prototype, "store", void 0);
__decorate([
    state()
], MyProfile.prototype, "_editing", void 0);
MyProfile = __decorate([
    customElement("my-profile")
], MyProfile);
export { MyProfile };
//# sourceMappingURL=my-profile.js.map