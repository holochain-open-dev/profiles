import { AgentPubKey } from "@holochain/client";
import { LitElement } from "lit";
/**
 * @element agents-avatars
 */
export declare class AgentsAvatars extends LitElement {
    agents: AgentPubKey[];
    render(): import("lit-html").TemplateResult<1>;
    static styles: (import("lit").CSSResult | import("lit").CSSResult[])[];
}
