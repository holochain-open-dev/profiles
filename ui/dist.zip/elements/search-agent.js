import { __decorate } from "tslib";
import { customElement, property, state, query } from "lit/decorators.js";
import { css, html, LitElement } from "lit";
import { consume } from "@lit/context";
import { localized, msg } from "@lit/localize";
import { FormFieldController, hashProperty, sharedStyles, } from "@holochain-open-dev/elements";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "@shoelace-style/shoelace/dist/components/menu/menu.js";
import "@shoelace-style/shoelace/dist/components/menu-item/menu-item.js";
import "@shoelace-style/shoelace/dist/components/dropdown/dropdown.js";
import "@shoelace-style/shoelace/dist/components/input/input.js";
import "./agent-avatar.js";
import "./profile-list-item-skeleton.js";
import "./search-agent-dropdown.js";
import { profilesStoreContext } from "../context.js";
/**
 * @element search-agent
 * @fires agent-selected - Fired when the user selects some agent. Detail will have this shape: { agentPubKey: HoloHash }
 */
let SearchAgent = class SearchAgent extends LitElement {
    constructor() {
        /** Form field properties */
        super(...arguments);
        /**
         * Whether this field is required if this element is used inside a form
         */
        this.required = false;
        /**
         * Whether this field is disabled if this element is used inside a form
         */
        this.disabled = false;
        /** Public attributes */
        /**
         * Whether to clear the field when an agent is selected.
         * @attr clear-on-select
         */
        this.clearOnSelect = false;
        /**
         * Whether to include my own agent as a possible agent to select.
         * @attr include-myself
         */
        this.includeMyself = false;
        /**
         * @internal
         */
        this._controller = new FormFieldController(this);
        this.searchFilter = "";
    }
    reportValidity() {
        const invalid = this.required !== false && this.value === undefined;
        if (invalid) {
            this._textField.setCustomValidity(`This field is required`);
            this._textField.reportValidity();
        }
        return !invalid;
    }
    async reset() {
        this.value = this.defaultValue;
        if (this.defaultValue) {
            const profile = await this.store.client.getAgentProfile(this.defaultValue);
            this._textField.value = (profile === null || profile === void 0 ? void 0 : profile.entry.nickname) || "";
        }
        else {
            this._textField.value = "";
        }
    }
    onUsernameSelected(agentPubKey, profile) {
        this.value = agentPubKey;
        // If the consumer says so, clear the field
        if (this.clearOnSelect) {
            this._textField.value = "";
        }
        else {
            this._textField.value = profile.entry.nickname;
        }
        this.searchFilter = "";
    }
    /**
     * @internal
     */
    get _label() {
        let l = this.fieldLabel ? this.fieldLabel : msg("Search Agent");
        if (this.required !== false)
            l = `${l} *`;
        return l;
    }
    render() {
        return html `
      <div style="flex: 1; display: flex;">
        <search-agent-dropdown
          id="dropdown"
          .open=${this.searchFilter.length >= 3}
          style="flex: 1"
          .includeMyself=${this.includeMyself}
          .searchFilter=${this.searchFilter}
          @agent-selected=${(e) => this.onUsernameSelected(e.detail.agentPubKey, e.detail.profile)}
        >
          <sl-input
            id="textfield"
            .label=${this._label}
            .placeholder=${msg("At least 3 chars...")}
            @input=${(e) => {
            this.searchFilter = e.target.value;
        }}
          ></sl-input>
        </search-agent-dropdown>
      </div>
    `;
    }
    static get styles() {
        return [
            sharedStyles,
            css `
        :host {
          display: flex;
        }
      `,
        ];
    }
};
__decorate([
    property()
], SearchAgent.prototype, "name", void 0);
__decorate([
    property(hashProperty("default-value"))
], SearchAgent.prototype, "defaultValue", void 0);
__decorate([
    property()
], SearchAgent.prototype, "required", void 0);
__decorate([
    property()
], SearchAgent.prototype, "disabled", void 0);
__decorate([
    state()
], SearchAgent.prototype, "value", void 0);
__decorate([
    property({ type: Boolean, attribute: "clear-on-select" })
], SearchAgent.prototype, "clearOnSelect", void 0);
__decorate([
    property({ type: Boolean, attribute: "include-myself" })
], SearchAgent.prototype, "includeMyself", void 0);
__decorate([
    property({ type: String, attribute: "field-label" })
], SearchAgent.prototype, "fieldLabel", void 0);
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], SearchAgent.prototype, "store", void 0);
__decorate([
    query("#textfield")
], SearchAgent.prototype, "_textField", void 0);
__decorate([
    state()
], SearchAgent.prototype, "searchFilter", void 0);
SearchAgent = __decorate([
    localized(),
    customElement("search-agent")
], SearchAgent);
export { SearchAgent };
//# sourceMappingURL=search-agent.js.map