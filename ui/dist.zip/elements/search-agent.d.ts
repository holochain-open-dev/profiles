import { LitElement } from "lit";
import { AgentPubKey } from "@holochain/client";
import { FormField, FormFieldController } from "@holochain-open-dev/elements";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
import "@shoelace-style/shoelace/dist/components/menu/menu.js";
import "@shoelace-style/shoelace/dist/components/menu-item/menu-item.js";
import "@shoelace-style/shoelace/dist/components/dropdown/dropdown.js";
import "@shoelace-style/shoelace/dist/components/input/input.js";
import "./agent-avatar.js";
import "./profile-list-item-skeleton.js";
import "./search-agent-dropdown.js";
import { Profile } from "../types.js";
import { ProfilesStore } from "../profiles-store.js";
import { EntryRecord } from "@holochain-open-dev/utils";
/**
 * @element search-agent
 * @fires agent-selected - Fired when the user selects some agent. Detail will have this shape: { agentPubKey: HoloHash }
 */
export declare class SearchAgent extends LitElement implements FormField {
    /** Form field properties */
    /**
     * The name of the field if this element is used inside a form
     * Required only if the element is used inside a form
     */
    name: string;
    /**
     * The default value of the field if this element is used inside a form
     */
    defaultValue: AgentPubKey | undefined;
    /**
     * Whether this field is required if this element is used inside a form
     */
    required: boolean;
    /**
     * Whether this field is disabled if this element is used inside a form
     */
    disabled: boolean;
    /**
     * @internal
     */
    value: AgentPubKey | undefined;
    /** Public attributes */
    /**
     * Whether to clear the field when an agent is selected.
     * @attr clear-on-select
     */
    clearOnSelect: boolean;
    /**
     * Whether to include my own agent as a possible agent to select.
     * @attr include-myself
     */
    includeMyself: boolean;
    /**
     * Label for the agent searching field.
     * @attr field-label
     */
    fieldLabel: string;
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /**
     * @internal
     */
    _controller: FormFieldController;
    reportValidity(): boolean;
    reset(): Promise<void>;
    /**
     * @internal
     */
    private _textField;
    searchFilter: string;
    onUsernameSelected(agentPubKey: AgentPubKey, profile: EntryRecord<Profile>): void;
    /**
     * @internal
     */
    get _label(): string;
    render(): import("lit-html").TemplateResult<1>;
    static get styles(): (import("lit").CSSResult | import("lit").CSSResult[])[];
}
