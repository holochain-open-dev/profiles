import { __decorate } from "tslib";
import { html, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
import { localized, msg, str } from "@lit/localize";
import { consume } from "@lit/context";
import { onSubmit, sharedStyles } from "@holochain-open-dev/elements";
import "@shoelace-style/shoelace/dist/components/avatar/avatar.js";
import "@shoelace-style/shoelace/dist/components/button/button.js";
import "@shoelace-style/shoelace/dist/components/input/input.js";
import "@shoelace-style/shoelace/dist/components/icon/icon.js";
import "@holochain-open-dev/elements/dist/elements/select-avatar.js";
import { profilesStoreContext } from "../context.js";
/**
 * @element edit-profile
 * @fires save-profile - Fired when the save profile button is clicked
 */
let EditProfile = class EditProfile extends LitElement {
    constructor() {
        super(...arguments);
        this.allowCancel = false;
    }
    /** Private properties */
    avatarMode() {
        return (this.store.config.avatarMode === "avatar-required" ||
            this.store.config.avatarMode === "avatar-optional");
    }
    fireSaveProfile(fields) {
        const nickname = fields["nickname"];
        delete fields["nickname"];
        const profile = {
            fields,
            nickname,
        };
        this.dispatchEvent(new CustomEvent("save-profile", {
            detail: {
                profile,
            },
            bubbles: true,
            composed: true,
        }));
    }
    fireCancel() {
        this.dispatchEvent(new CustomEvent("cancel-edit-profile", {
            bubbles: true,
            composed: true,
        }));
    }
    renderField(fieldConfig) {
        var _a;
        return html `
      <sl-input
        name="${fieldConfig.name}"
        .required=${fieldConfig.required}
        .label=${fieldConfig.label}
        .value=${((_a = this.profile) === null || _a === void 0 ? void 0 : _a.entry.fields[fieldConfig.name]) || ""}
        style="margin-bottom: 16px;"
      ></sl-input>
    `;
    }
    render() {
        var _a, _b, _c;
        return html `
      <form
        id="profile-form"
        class="column"
        ${onSubmit((fields) => this.fireSaveProfile(fields))}
      >
        <div
          class="row"
          style="justify-content: center; align-self: start; margin-bottom: 16px"
        >
          ${this.avatarMode()
            ? html ` <select-avatar
                name="avatar"
                .value=${((_a = this.profile) === null || _a === void 0 ? void 0 : _a.entry.fields["avatar"]) || undefined}
                .required=${this.store.config.avatarMode === "avatar-required"}
              ></select-avatar>`
            : html ``}

          <sl-input
            name="nickname"
            .label=${msg("Nickname")}
            required
            minLength="${this.store.config.minNicknameLength}"
            .value=${((_b = this.profile) === null || _b === void 0 ? void 0 : _b.entry.nickname) || ""}
            .helpText=${msg(str `Min. ${this.store.config.minNicknameLength} characters`)}
            style="margin-left: 16px;"
          ></sl-input>
        </div>

        ${this.store.config.additionalFields.map((field) => this.renderField(field))}

        <div class="row" style="margin-top: 8px;">
          ${this.allowCancel
            ? html `
                <sl-button
                  style="flex: 1; margin-right: 6px;"
                  @click=${() => this.fireCancel()}
                >
                  ${msg("Cancel")}
                </sl-button>
              `
            : html ``}

          <sl-button style="flex: 1;" variant="primary" type="submit"
            >${(_c = this.saveProfileLabel) !== null && _c !== void 0 ? _c : msg("Save Profile")}
          </sl-button>
        </div>
      </form>
    `;
    }
};
EditProfile.styles = [sharedStyles];
__decorate([
    property({ type: Object })
], EditProfile.prototype, "profile", void 0);
__decorate([
    property({ type: String, attribute: "save-profile-label" })
], EditProfile.prototype, "saveProfileLabel", void 0);
__decorate([
    consume({ context: profilesStoreContext, subscribe: true }),
    property()
], EditProfile.prototype, "store", void 0);
__decorate([
    property({ type: Boolean, attribute: "allow-cancel" })
], EditProfile.prototype, "allowCancel", void 0);
EditProfile = __decorate([
    localized(),
    customElement("edit-profile")
], EditProfile);
export { EditProfile };
//# sourceMappingURL=edit-profile.js.map