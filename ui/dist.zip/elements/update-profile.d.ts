import { LitElement } from "lit";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "@shoelace-style/shoelace/dist/components/spinner/spinner.js";
import "./edit-profile.js";
import { ProfilesStore } from "../profiles-store.js";
import { Profile } from "../types.js";
/**
 * @element update-profile
 * @fires profile-updated - Fired after the profile has been created. Detail will have this shape: { profile: { nickname, fields } }
 */
export declare class UpdateProfile extends LitElement {
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /**
     * @internal
     */
    private _myProfile;
    updateProfile(profile: Profile): Promise<void>;
    render(): import("lit-html").TemplateResult<1>;
    static get styles(): (import("lit").CSSResult | import("lit").CSSResult[])[];
}
