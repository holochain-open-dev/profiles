import { LitElement } from "lit";
import "@shoelace-style/shoelace/dist/components/skeleton/skeleton.js";
/**
 * @element profile-list-item-skeleton
 */
export declare class ProfileListItemSkeleton extends LitElement {
    render(): import("lit-html").TemplateResult<1>;
    static get styles(): (import("lit").CSSResult | import("lit").CSSResult[])[];
}
