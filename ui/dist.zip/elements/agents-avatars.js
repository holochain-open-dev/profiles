import { __decorate } from "tslib";
import { sharedStyles } from "@holochain-open-dev/elements";
import { localized } from "@lit/localize";
import { LitElement, css, html } from "lit";
import { customElement, property } from "lit/decorators.js";
/**
 * @element agents-avatars
 */
let AgentsAvatars = class AgentsAvatars extends LitElement {
    render() {
        return html `
      <div class="row avatar-group">
        ${this.agents
            .slice(0, 3)
            .map((a) => html `<agent-avatar .agentPubKey=${a}></agent-avatar>`)}
        ${this.agents.length > 3
            ? html `<sl-avatar
              .initials=${`+${this.agents.length - 3}`}
              style="--size: 32px"
            ></sl-avatar>`
            : html ``}
      </div>
    `;
    }
};
AgentsAvatars.styles = [
    css `
      .avatar-group agent-avatar:not(:first-of-type) {
        margin-left: -0.5rem;
      }
    `,
    sharedStyles,
];
__decorate([
    property()
], AgentsAvatars.prototype, "agents", void 0);
AgentsAvatars = __decorate([
    localized(),
    customElement("agents-avatars")
], AgentsAvatars);
export { AgentsAvatars };
//# sourceMappingURL=agents-avatars.js.map