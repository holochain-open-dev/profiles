import { LitElement } from "lit";
import { AgentPubKey } from "@holochain/client";
import "@holochain-open-dev/elements/dist/elements/display-error.js";
import "./agent-avatar.js";
import "./profile-list-item-skeleton.js";
import { ProfilesStore } from "../profiles-store";
import { Profile } from "../types";
import { EntryRecord } from "@holochain-open-dev/utils";
/**
 * @element list-profiles
 * @fires agent-selected - Fired when the user selects an agent from the list. Detail will have this shape: { agentPubKey: <AGENT_PUB_KEY as Uint8Array> }
 */
export declare class ListProfiles extends LitElement {
    /**
     * Profiles store for this element, not required if you embed this element inside a <profiles-context>
     */
    store: ProfilesStore;
    /** Private properties */
    /**
     * @internal
     */
    private _allProfiles;
    initials(nickname: string): string;
    fireAgentSelected(agentPubKey: AgentPubKey): void;
    renderList(profiles: ReadonlyMap<AgentPubKey, EntryRecord<Profile>>): import("lit-html").TemplateResult<1>;
    render(): import("lit-html").TemplateResult<1>;
    static styles: (import("lit").CSSResult | import("lit").CSSResult[])[];
}
