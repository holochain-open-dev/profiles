import { decodeHashFromBase64, encodeHashToBase64, } from "@holochain/client";
export function uniquify(array) {
    const strArray = array.map((h) => encodeHashToBase64(h));
    const uniqueArray = [...new Set(strArray)];
    return uniqueArray.map((h) => decodeHashFromBase64(h));
}
//# sourceMappingURL=stores.js.map