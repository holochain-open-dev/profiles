export const defaultConfig = {
    avatarMode: 'avatar-optional',
    additionalFields: [],
    minNicknameLength: 3,
};
//# sourceMappingURL=config.js.map