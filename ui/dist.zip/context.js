import { createContext } from "@lit/context";
export const profilesStoreContext = createContext("hc_zome_profiles/store");
//# sourceMappingURL=context.js.map