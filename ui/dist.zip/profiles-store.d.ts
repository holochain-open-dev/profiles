import { EntryRecord, LazyHoloHashMap } from "@holochain-open-dev/utils";
import { AsyncReadable } from "@holochain-open-dev/stores";
import { AgentPubKey } from "@holochain/client";
import { ProfilesClient } from "./profiles-client.js";
import { Profile } from "./types.js";
import { ProfilesConfig } from "./config.js";
export declare function catchNotFoundError<T>(store: AsyncReadable<T>): AsyncReadable<T | undefined>;
export declare class ProfilesStore {
    client: ProfilesClient;
    config: ProfilesConfig;
    constructor(client: ProfilesClient, config?: Partial<ProfilesConfig>);
    /**
     * Fetches all the agents that have created a profile in the DHT
     */
    agentsWithProfile: AsyncReadable<AgentPubKey[]>;
    /**
     * Fetches the profiles for all agents in the DHT
     *
     * This will get slower as the number of agents in the DHT increases
     */
    allProfiles: AsyncReadable<ReadonlyMap<Uint8Array, EntryRecord<Profile>>>;
    /**
     * Fetches the profile for the given agent
     */
    profiles: LazyHoloHashMap<Uint8Array, AsyncReadable<EntryRecord<Profile> | undefined>>;
    myProfile: AsyncReadable<EntryRecord<Profile> | undefined>;
    agentsProfiles(agents: Array<AgentPubKey>): AsyncReadable<ReadonlyMap<AgentPubKey, EntryRecord<Profile> | undefined>>;
    searchProfiles(searchFilter: string): AsyncReadable<ReadonlyMap<AgentPubKey, EntryRecord<Profile>>>;
}
