import { EntryRecord, LazyHoloHashMap } from "@holochain-open-dev/utils";
import { encode } from "@msgpack/msgpack";
import { asyncReadable, lazyLoad, sliceAndJoin, pipe, derived, NotFoundError, } from "@holochain-open-dev/stores";
import { defaultConfig } from "./config.js";
import { uniquify } from "./stores.js";
// @ts-ignore
import isEqual from "lodash-es/isEqual.js";
export function catchNotFoundError(store) {
    return derived(store, (asyncStatus) => {
        if (asyncStatus.status !== "error")
            return asyncStatus;
        if (asyncStatus.error instanceof NotFoundError)
            return {
                status: "complete",
                value: undefined,
            };
        return asyncStatus;
    });
}
export class ProfilesStore {
    constructor(client, config = {}) {
        this.client = client;
        /**
         * Fetches all the agents that have created a profile in the DHT
         */
        this.agentsWithProfile = asyncReadable(async (set) => {
            let hashes;
            const fetch = async () => {
                const nhashes = await this.client.getAgentsWithProfile();
                if (!isEqual(nhashes, hashes)) {
                    hashes = uniquify(nhashes);
                    set(hashes);
                }
            };
            await fetch();
            const interval = setInterval(() => fetch(), 4000);
            const unsubs = this.client.onSignal((signal) => {
                if (signal.type === "LinkCreated") {
                    if ("AgentToProfile" in signal.link_type) {
                        hashes = uniquify([...hashes, this.client.client.myPubKey]);
                        set(hashes);
                    }
                }
            });
            return () => {
                clearInterval(interval);
                unsubs();
            };
        });
        /**
         * Fetches the profiles for all agents in the DHT
         *
         * This will get slower as the number of agents in the DHT increases
         */
        this.allProfiles = pipe(this.agentsWithProfile, (agents) => this.agentsProfiles(agents));
        /**
         * Fetches the profile for the given agent
         */
        this.profiles = new LazyHoloHashMap((agent) => asyncReadable(async (set) => {
            const profile = await this.client.getAgentProfile(agent);
            set(profile);
            return this.client.onSignal((signal) => {
                if (this.client.client.myPubKey.toString() !== agent.toString())
                    return;
                if (!(signal.type === "EntryCreated" || signal.type === "EntryUpdated"))
                    return;
                const record = new EntryRecord({
                    entry: {
                        Present: {
                            entry_type: "App",
                            entry: encode(signal.app_entry),
                        },
                    },
                    signed_action: signal.action,
                });
                set(record);
            });
        }));
        // Fetches your profile
        this.myProfile = this.profiles.get(this.client.client.myPubKey);
        this.config = { ...defaultConfig, ...config };
    }
    // Fetches the profiles for the given agents
    agentsProfiles(agents) {
        return sliceAndJoin(this.profiles, agents);
    }
    searchProfiles(searchFilter) {
        return pipe(lazyLoad(async () => this.client.searchAgents(searchFilter)), (agents) => this.agentsProfiles(agents));
    }
}
//# sourceMappingURL=profiles-store.js.map